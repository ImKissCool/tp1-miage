package com.acme.mailreader.utils;

public class MailInvalidateException {

}
