package com.acme.mailreader.serveur;

public class SMTPMailSender {

}
