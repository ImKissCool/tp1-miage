package com.acme.mailreader.serveur;

public class MailSender {

}
