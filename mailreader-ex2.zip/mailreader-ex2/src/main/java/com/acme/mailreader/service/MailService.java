package com.acme.mailreader.service;

public class MailService {

}
