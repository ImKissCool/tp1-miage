package com.acme.mailreader.presentation;

public class ClientMail {

}
