package com.acme.mailreader.commun;

public class MailReaderModule {

}
