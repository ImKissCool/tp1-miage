package com.acme.mailreader.utils;

public class MailSender {

}
